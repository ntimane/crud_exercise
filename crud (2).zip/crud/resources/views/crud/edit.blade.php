@extends('layout')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Update Contact
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('crud.update', $cruds->id) }}">
        {!! $grid !!}
        @method('PATCH')
        @csrf
        <div class="form-group">
          <label for="first_name">First Name:</label>
          <input type="text" class="form-control" name="first_name" value={{ $cruds->first_name }} />
        </div>
        <div class="form-group">
          <label for="last_name">Last Name :</label>
          <input type="text" class="form-control" name="last_name" value={{ $cruds->last_name }} />
        </div>
        <div class="form-group">
          <label for="mobile">Mobile No:</label>
          <input type="text" class="form-control" name="mobile" value={{ $cruds->mobile }} />
        </div>
        <div class="form-group">
          <label for="email_address">Email Address:</label>
          <input type="email" class="form-control" name="email_address" value={{ $cruds->email_address }} />
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
  </div>
</div>
@endsection
